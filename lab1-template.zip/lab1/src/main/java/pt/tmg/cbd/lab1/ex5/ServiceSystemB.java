package pt.tmg.cbd.lab1.ex5;

public class ServiceSystemB {
    public static void main(String[] args) {
        // TODO: Complete me
    }
}
