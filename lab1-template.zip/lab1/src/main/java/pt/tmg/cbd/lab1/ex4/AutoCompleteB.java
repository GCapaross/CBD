package pt.tmg.cbd.lab1.ex4;

public class AutoCompleteB {
    public static void main(String[] args) {
        // TODO: Complete me
    }
}
