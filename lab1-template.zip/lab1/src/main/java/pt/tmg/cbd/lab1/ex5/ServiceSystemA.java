package pt.tmg.cbd.lab1.ex5;

public class ServiceSystemA {
    public static void main(String[] args) {
        // TODO: Complete me
    }
}
